
#' Mediated moderation analysis with the debiased machine learning method
#' @param data a \code{data.frame} containing variables involved in the analysis.
#' @param outcome a character string of the name of the column in "data" that correspond to the outcome variable (Y).
#' @param mediators a character vector of the names of the columns in "data" that correspond to the mediator M1. The definition for the mediated moderation via mediator M1 (i.e., MedMod_M1) considers shifting the levels of M1, while fixing the levels of mediator M2 at its levels among the reference subgroup.
#' @param treatment a character string of the name of the column in "data" that correspond to the treatment variable (T). The treatment variable should be dummy coded (e.g., 1 for the intervention condition, 0 for the control condition).
#' @param subgroup a character string of the name of the column in "data" that correspond to the moderator subgroup status (R). The subgroup status should be dummy coded, with 1 for the focal subgroup and 0 for the reference subgroup.
#' @param covariates a character vector of the names of the columns in "data" that correspond to pretreatment (i.e., baseline) covariates (C).
#' @param learners a character vector specifying the methods for estimating the nuisance models. Currently supported options include the list of methods included in the "SuperLearner" package (<https://cran.r-project.org/package=SuperLearner>), which can be listed via function listWrappers() of the "SuperLearner" package.
#' @param num_folds the number of folds used for the cross-fitting procedure.
#' @param fity.interact logical; if \code{TRUE}, the outcome nuisance models include interactions among the treatment, subgroup, and the mediators. Defaults to \code{FALSE}.
#' @param fitm.interact logical; if \code{TRUE}, the mediator nuisance models include interactions among the treatment, subgroup, and the mediators. Defaults to \code{FALSE}.
#'
#'
#'
#' @return A data frame containing the results for the mediated moderation estimands and the expected potential outcomes in the estimands. The results include the estimates, standard error estimates, and 0.95 confidence intervals. The returned data frame also carries an attribute \code{"probabilities"}: a named list of the cross-fitted treatment/subgroup probability estimates (one row per observation) -- \code{joint_tr_c} = p(T, R | C), \code{subgroup_r_c} = p(R | C), and \code{treatment_t_rc} = p(T | R, C). Retrieve it with \code{\link{MedMod_probabilities}}. It also carries an attribute \code{"fit_inputs"}: the data, variable-role map, cross-fitting folds, learners, and mediator family needed to re-fit the mediator-side nuisances on demand (used by \code{\link{MedMod_mediator_positivity}}). Retrieve it with \code{\link{MedMod_fit_inputs}}.
#'
#' @examples
#'

#' library(tidyverse)
#' library(glue)
#' library(origami)
#' library(mvtnorm)
#' library(SuperLearner)
#' library(ranger)
#' library(nnet)
#'
#' # Run ----------
#' data <- MedMod::data
#' head(data)
#'
#' set.seed(12345)
#' out <- MedMod::MedMod(
#'   data = data, # data containing all variables
#'   outcome = "Outcome", # name of outcome
#'   mediators = c("M1", "M2"), # name of mediators. When more than two mediators are included, the first mediator is designated as M1, and all remaining mediators are collectively treated as M2.
#'   treatment = "Intervention", # name of treatment variable
#'   subgroup = "Male", # name of moderator subgroup variable
#'   covariates = c("C.1", "C.2", "C.3"), # names of baseline covariates
#'   learners = c("SL.mean", "SL.glm", "SL.ranger", "SL.nnet"),
#'   # methods from the SuperLearner package to include in the super learner ensemble (intercept-only model, generalized linear model, random forest, neural network).
#'   # To see all available methods, run: SuperLearner::listWrappers()
#'   num_folds = 4, # number of folds for cross-fitting
#'   fity.interact = TRUE, # include treatment/subgroup/mediator interactions in the outcome nuisance models
#'   fitm.interact = TRUE, # include treatment/subgroup/mediator interactions in the mediator nuisance models
#'   ci.level = 0.95 # default: 95% confidence interval
#' )
#' # Extract results for mediated moderation
#' out %>%
#'   filter(Estimand %in% c("TotMod", "MedMod", "RemainMod", # Total moderation, Mediated moderation, Remaining  moderation
#'                          "MedMod_M1", "MedMod_M2", "MedMod_mu")) # When more than one mediators, the output also include: Mediated moderation via M1, Mediated moderation via M2, Mediated moderation due to mediators' mutual dependence
#'
#'
#' @export
#'


#'
#'
MedMod <- function(
    data,
    outcome,
    mediators,
    treatment,
    subgroup,
    covariates,
    learners = c("SL.glm"),
    learners_h = NULL,
    learners_mu = NULL,
    num_folds = 5,
    fity.interact = FALSE,
    fitm.interact = FALSE,
    ci.level = 0.95
) {

  # inputs -----------
  M1names <- mediators[1]

  if (length(mediators) > 1) {
    M2names <- mediators[-1]
  } else {
    M2names <- NULL
  }


  Yname <- outcome
  ttname <- treatment
  Rname <- subgroup
  Cnames <- covariates

  # Mediators <- list(M1names, M2names)
  Yfamily <- ifelse(length(unique(data[[Yname]])) > 2, "gaussian", "binomial")

  Mfamily <- "h" # one or more continuous mediators
  if((nrow(unique(data[, M1names, drop=FALSE])) == 2) & (nrow(unique(data[, M2names, drop=FALSE])) <= 2)) {
    Mfamily <- "b"
  }

  data_in <- data
  Znames <- M1names #Mediators[[1]]
  Mnames <- M2names #Mediators[[2]]
  data_in <- data_in %>% mutate(
    Rtt = data_in[[Rname]] * data_in[[ttname]]
  )
  if (!is.null(Znames)) {
    data_in <- data_in %>% mutate(
      RZ = data_in[[Rname]] * data_in[, Znames],
      ttZ = data_in[[ttname]] * data_in[, Znames],
      ttRZ = data_in[[ttname]] * data_in[[Rname]] * data_in[, Znames]
    )
  }
  if (!is.null(Mnames)) {
    data_in <- data_in %>% mutate(
      RM = data_in[[Rname]] * data_in[, Mnames],
      ttM = data_in[[ttname]] * data_in[, Mnames],
      ttRM = data_in[[Rname]] * data_in[[ttname]] * data_in[, Mnames]
    )
  }

  if (!is.null(Znames) & !is.null(Mnames)) {
    data_in <- data_in %>% mutate(
      MZ = data_in[, Znames] * data_in[, Mnames],
      ttMZ = data_in[[ttname]] * data_in[, Znames] * data_in[, Mnames],
      RMZ = data_in[[Rname]] * data_in[, Znames] * data_in[, Mnames],
      ttRMZ = data_in[[ttname]] * data_in[[Rname]] * data_in[, Znames] * data_in[, Mnames]
    )
  }

  data_in <- do.call(data.frame, data_in)

  varnames <- list("R" = Rname, "tt" = ttname, "M" = Mnames, "Y" = Yname,
                   "Z" = Znames, "C" = Cnames,
                   "Rtt" = paste0("Rtt"), "RM" = paste0("RM"), "ttM" = paste0("ttM"), "ttRM" = paste0("ttRM"),
                   "RZ" = paste0("RZ"), "ttZ" = paste0("ttZ"), "MZ" = paste0("MZ"),
                   "ttRZ" = "ttRZ", "ttMZ" = "ttMZ", "RMZ" = "RMZ", "ttRMZ" = "ttRMZ")
  if (is.null(Mnames)) {
    varnames[grep("M", names(varnames), value = TRUE)] <- NULL
  }
  data_in$ID <- 1:nrow(data_in)

  folds <- origami::make_folds(n = nrow(data_in), V = num_folds)
  if (num_folds==1) {
    folds[[1]]$training_set <- folds[[1]]$validation_set
  }
  if (num_folds > 1) {
    folds <- vector("list", length = num_folds)

    tr_vals <- expand.grid(tt=c(0,1), r=c(0,1))
    j <- 1
    for(j in 1:nrow(tr_vals)) {
      id_tr <- (data_in[[varnames$tt]] == tr_vals$tt[j]) &
        (data_in[[varnames$R]] == tr_vals$r[j])

      z <- origami::make_folds(data_in[id_tr, ], V = num_folds)

      k <- 1
      for (k in 1:num_folds) {
        folds[[k]]$v <- k
        folds[[k]]$training_set <- c(folds[[k]]$training_set, data_in[id_tr, "ID"][z[[k]]$training_set])
        folds[[k]]$validation_set <- c(folds[[k]]$validation_set, data_in[id_tr, "ID"][z[[k]]$validation_set])
        attr(folds[[k]], "class")<-"fold"
      }
    }


  }

  if (is.null(learners_h)) {
    learners_h <- learners
  }
  if (is.null(learners_mu)) {
    learners_mu <- learners
  }
  medmod_data <- mget(ls(), envir = environment())

  if (Mfamily=="b") {
    out <- b.MedMod(
      medmod_data = medmod_data,
      fity.interact = fity.interact,
      fitm.interact = fitm.interact,
      TotMod_dr = FALSE
    )
  }

  if (Mfamily=="h") {

    out <- h.MedMod(
      medmod_data = medmod_data,
      fity.interact = fity.interact,
      fitm.interact = fitm.interact,
      TotMod_dr = FALSE,
      full.sample = TRUE
    )
  }

  list2env(out, envir = environment())

  # estimates and inferences --------------------
  eifs_effs <- effect(eif)
  thetas_effs <- sapply(eifs_effs, mean)
  se_effs <- sapply(eifs_effs, function(s) {
    sqrt(var(s) / length(s))
  })
  ci_effs <- sapply(eifs_effs, function(s) {
    mean(s) + c(-1, 1) * qnorm(1-(1-ci.level)/2) * sqrt(var(s) / length(s))
  })

  # regression
  regs_effs <- unlist(effect(reg))
  # weighting
  rmpw_effs <- unlist(effect(rmpw))

  estimates <- cbind(
    est_multi = thetas_effs,
    se_multi = se_effs,
    ci1_multi = ci_effs[1, ],
    ci2_multi = ci_effs[2, ]
    ,est_reg = regs_effs,
    est_rmpw = rmpw_effs
  )
  out <- list(estimates = estimates, eifs = eifs_effs)

  out$estimates <- data.frame(out$estimates) %>%
    rownames_to_column(var = "Estimand") %>%
    mutate(Estimand = ifelse(Estimand == "MedMod_jo", "MedMod", Estimand)) %>%
    rename(Estimate=est_multi, std.error=se_multi,
           `CI.lower`=ci1_multi, `CI.upper`=ci2_multi) %>%
    select(!c(est_rmpw,est_reg))

  # Attach the cross-fitted treatment/subgroup probability estimates (computed in
  # h.MedMod / b.MedMod and brought into scope by the list2env() above) as an
  # attribute, so the returned object stays a plain data.frame. Retrieve via
  # MedMod_probabilities().
  attr(out$estimates, "probabilities") <- list(
    joint_tr_c     = tr_c,   # p(T, R | C)  -- joint treatment x subgroup propensity
    subgroup_r_c   = r_c,    # p(R | C)     -- subgroup probability
    treatment_t_rc = t_rc    # p(T | R, C)  -- treatment probability
  )

  # Attach the ingredients needed to re-fit the probabilities on demand
  # (with bounded = FALSE) for the positivity diagnostic. These re-fits must
  # use the same cross-fitting folds as the original estimator, which are random per
  # call and cannot be reconstructed from the raw data, and hence we carry the fitted
  # folds (and the rest of the fit context) here. Retrieve via MedMod_fit_inputs() and
  # consume in MedMod_overlap() and MedMod_mediator_positivity().
  attr(out$estimates, "fit_inputs") <- list(
    data_in       = data_in,
    varnames      = varnames,
    folds         = folds,
    learners      = learners,
    fitm.interact = fitm.interact,
    Mfamily       = Mfamily
  )

  # out
  out$estimates
}


#' Extract estimated treatment and subgroup probabilities from a MedMod fit
#'
#' @param object the object returned by \code{\link{MedMod}}.
#'
#' @return A named list of cross-fitted probability matrices, each with one row per
#'   observation: \code{joint_tr_c} = p(T, R | C), the joint treatment-by-subgroup
#'   propensity; \code{subgroup_r_c} = p(R | C), the subgroup probability; and
#'   \code{treatment_t_rc} = p(T | R, C), the treatment probability. Returns
#'   \code{NULL} if no probabilities are attached.
#'
#' @export
MedMod_probabilities <- function(object) {
  attr(object, "probabilities")
}


#' Extract the fit context needed to re-fit MedMod nuisances on demand
#'
#' Returns the bundle of inputs attached by \code{\link{MedMod}} so that downstream
#' diagnostics can re-fit the mediator-side nuisance models on the original data and the
#' original cross-fitting folds. This is used by \code{\link{MedMod_mediator_positivity}},
#' which re-fits those nuisances with \code{bounded = FALSE} so that probability truncation
#' cannot hide positivity violations.
#'
#' @param object the object returned by \code{\link{MedMod}}.
#'
#' @return A named list with elements \code{data_in} (the model-frame data, including the
#'   interaction columns and the \code{ID} column), \code{varnames} (the variable-role map),
#'   \code{folds} (the cross-fitting folds), \code{learners} (the SuperLearner library),
#'   \code{fitm.interact} (whether the mediator nuisance models include interactions), and
#'   \code{Mfamily} (\code{"b"} for all-binary mediators, \code{"h"} when any mediator is
#'   continuous). Returns \code{NULL} if no fit inputs are attached.
#'
#' @export
MedMod_fit_inputs <- function(object) {
  attr(object, "fit_inputs")
}
