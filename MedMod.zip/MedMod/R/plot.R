# to edit
plot.medmod <- function(eif, subgroup_levels = c(comparison = "comparison", reference = "reference"), treatment_levels = c(intervention = "intervention", control = "control")) {
  
  
  #names(binaryout1$eifs_effs)
  eifs <- out$eifs_effs
  estimates1_lift <- data.frame(out$estimates) %>% 
    rownames_to_column(var = "estimand")
  
  TE_r1 <- eif2ci(eifs$`delta(t1,r1)`-eifs$`delta(t0,r1)`)
  TE_r1
  
  TE_r0 <- eif2ci(eifs$`delta(t1,r0)`-eifs$`delta(t0,r0)`)
  TE_r0
  
  newEst <- data.frame(rbind(TE_r0, TE_r1)) %>% 
    rownames_to_column(var = "estimand")
  
  est_tab <- (estimates1_lift) %>% 
    select(estimand, est_multi, ci1_multi, ci2_multi) %>% 
    # filter(str_detect(estimand, "Mod")) %>% 
    bind_rows(newEst) %>% 
    mutate(across(where(is.numeric), ~round(., 2))) %>% 
    mutate(ci = glue("({ci1_multi}, {ci2_multi})")) %>% 
    select(estimand, est_multi, ci)
  
  # est_tab %>% write_csv(., file = "Tables_Figs/lift_est_tab.csv")
  
  # Bars of thetas -------------------
  
  
  # plotdf_Rfe <- tab_Rfe %>%
  plotdf_Rmale <- estimates1_lift %>%
    select(estimand, est_multi, ci1_multi, ci2_multi) %>% 
    filter(
      str_detect(estimand, "theta")
      # effect %in% c("Yt1r1","Yt1r0","Yt0r1","Yt0r0", "Yt1r1.Mt1r0", "Yt0r1.Mt0r0")
    ) %>% 
    mutate(
      numtype = case_when(
        estimand %in% c(glue("theta(t{c(0,1)},r1,rjo1)"), glue("theta(t{c(0,1)},r0,rjo0)")) ~ 1 ,
        estimand %in% c(glue("theta(t{c(0,1)},r1,r1,r1)")) ~ 2,
        estimand %in% c(glue("theta(t{c(0,1)},r1,r1,r0)")) ~ 3 ,
        estimand %in% c(glue("theta(t{c(0,1)},r1,r0,r0)")) ~ 4 ,
        estimand %in% c(glue("theta(t{c(0,1)},r1,rjo0)")) ~ 5 
      ),
      type = factor(numtype, levels = c(1:5), labels = c(
        "As natural", #1
        "If each of M1 and M2 were independently set at their distributions among the comparison subgroup (within strata of the covariates)", #2
        "If M2 were shifted to equal the reference subgroup, while fixing M1 at its distribution among the comparison subgroup (within strata of the covariates)", #3
        "If M1 were also shifted to equal the reference subgroup, while fixing M2 at its distribution among the reference subgroup (within strata of the covariates)",
        "If both M1 and M2 jointly were shifted to equal the reference subgroup (within strata of the covariates)"
      )),
      subgroup = case_when(
        substr(estimand, 10,11) == "r1" ~ "boys (comparison)",
        substr(estimand, 10,11) == "r0" ~ "girls (reference)"
      ),
      `Treatment assignment` = factor(ifelse(str_detect(estimand, "t1"), "Intervention", "Control"))
    )
  
  
  
  # theme ggplot -------------------
  fig.theme <- 
    theme_bw() +
    theme(panel.grid.minor = element_line(linewidth = 0),
          panel.grid.major.x = element_line(linewidth = 0),
          panel.grid.major.y = element_line(linewidth = 0.5, lineend = "round", color = "grey", linetype = "longdash"),
          # axis.text.x = element_text(angle = 0, vjust = 0, hjust = 0),
          plot.title = element_text(size = 12, face = "plain"),
          axis.text.x = element_text(size = 13),
          axis.text.y = element_text(size = 12),
          axis.title.y = element_text(size = 13),
          axis.title.x = element_text(size = 13),
          strip.text.x = element_text(size = 13),
          strip.text.y = element_text(size = 13),
          legend.text = element_text(size = 13),
          legend.title = element_text(size = 13),
          legend.direction = "vertical",
          legend.box = "vertical",
          legend.position = "bottom",
          legend.spacing.x = unit(0.2, "mm"),
          legend.key.height = unit(10, "mm"),
          legend.key.width = unit(10, "mm"),
          legend.key.size = unit(10, "mm"))
  
  
  ## M_joint -------------------------
  
  fig_male_joint <- plotdf_Rmale %>% 
    filter(numtype %in% c(1, 5)) %>% 
    mutate(type = factor(numtype, levels = c(1,5), labels = c(
      "As natural",
      "If the mediator were shifted to equal the reference subgroup (within strata of the covariates)"
    ))) %>% 
    ggplot(aes(y = est_multi, x = subgroup #, 
               # pattern = type #, color = type 
               # , fill = type
    ) ) +
    geom_bar(
      aes(linetype = type, fill = type),
      
      alpha = 0.4, stat = "identity", 
      color = "black",
      linewidth =0.4,
      position = position_dodge()) +
    # geom_point( aes(shape = type) ) +
    geom_errorbar( aes(ymax = ci2_multi, ymin = ci1_multi
                       ,linetype = type
    ),
    position = position_jitterdodge(jitter.width = 0, jitter.height = 0, dodge.width = 0.9), #"dodge", 
    width = 0.4, linewidth =0.6 ) +
    scale_y_continuous("Estimated risk of later tobacco use (Y)", breaks = seq(0.2,0.9,0.2)) +
    coord_cartesian(ylim = c(0.2, 0.9)) +
    # scale_x_discrete("Treatment assignment in grade 5") + 
    scale_x_discrete("Subgroup") + 
    # ggtitle("Tobacco use (Y)") +
    # annotate("text", x = 0.1, y = 0.95, label = "The results were adjusted for observed baseline covariates.") +
    scale_fill_discrete("Mediator") +
    scale_color_discrete("Mediator") +
    scale_linetype_discrete("Mediator") +
    # scale_pattern_discrete("Mediator")+
    facet_grid(. ~ `Treatment assignment`, labeller = label_value) +
    fig.theme +
    theme(
      legend.text = element_text(size = 18),
      strip.text = element_text(size = 18),
      axis.text.x = element_text(size = 17),
      axis.title.y = element_text(size = 17),
      legend.title = element_text(size = 20)
    )
  
  fig_male_joint
  
  # ggsave("Tables_Figs/Mjoint_fig_LIFT_Methods_Demo.pdf",width = 12, height = 9)
  
  ## M1 and M2 ------------------------
  
  # fig_female <- ggplot(data = plotdf_Rfe,
  fig_male <- plotdf_Rmale %>% 
    ggplot(aes(y = est_multi, x = subgroup
    ) ) + 
    # geom_bar_pattern(
    #   aes(linetype = type, fill = type),
    #   # fill = "white", 
    #   # pattern_fill = "black",
    #   pattern_angle = 45,
    #   # pattern_density = 0.05,
    #   pattern_spacing = 0.1,
    #   pattern_key_scale_factor = 0.3,
    #   alpha = 0.4, stat = "identity", 
    #   color = "black",
    #   linewidth =0.4,
    #   position = position_dodge()) +
    # geom_point( aes(shape = type) ) +
    geom_bar(
      aes(linetype = type, fill = type),
      
      alpha = 0.4, stat = "identity",
      color = "black",
      # linewidth =0.4,
      position = position_dodge()) +
    geom_point( aes(shape = type) ) +
    geom_errorbar( aes(ymax = ci2_multi, ymin = ci1_multi
                       ,linetype = type
    ),
    position = position_jitterdodge(jitter.width = 0, jitter.height = 0, dodge.width = 0.9), #"dodge", 
    width = 0.4, linewidth =0.6 ) +
    scale_y_continuous("Estimated risk of later tobacco use (Y)", breaks = seq(0.2,0.9,0.2)) +
    coord_cartesian(ylim = c(0.2, 0.9)) +
    # scale_x_discrete("Treatment assignment in grade 5") + 
    scale_x_discrete("Subgroup") + 
    # ggtitle("Tobacco use (Y)") +
    # annotate("text", x = 0.1, y = 0.95, label = "The results were adjusted for observed baseline covariates.") +
    scale_fill_discrete("Mediators (M1, M2)") +
    scale_color_discrete("Mediators (M1, M2)") +
    scale_linetype_discrete("Mediators (M1, M2)") +
    # scale_pattern_discrete("Mediators (M1, M2)")+
    facet_grid(. ~ `Treatment assignment`, labeller = label_value) +
    fig.theme +
    theme(
      legend.text = element_text(size = 18),
      strip.text = element_text(size = 18),
      axis.text.x = element_text(size = 17),
      axis.title.y = element_text(size = 17),
      legend.title = element_text(size = 20)
    )
  
  
  fig_male
  
  # dir()
  # ggsave("Tables_Figs/M1pcr8_M2dvp8_fig_LIFT_Methods_Demo.pdf", width = 18, height = 9)
  
}
# load("lift_results.RData")
# load("~/Library/CloudStorage/Box-Box/FSCTR Lab Publication Tracker/Methods Demo Paper/Drafts/LIFT_Methods_Demo.RData")

eif2ci <- function(eif) {
  Est <- mean(eif)
  SE <- sqrt(var(eif)/length(eif))
  ci1 <- Est + qnorm(0.975)*SE
  ci2 <- Est - qnorm(0.975)*SE
  c(est_multi=Est, ci1_multi=ci1, ci2_multi=ci2) #%>% round(., 2)
}
